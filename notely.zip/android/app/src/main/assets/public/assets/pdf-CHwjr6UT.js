const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["./index-_lHnZJZJ.js","./index-BjSsOXs8.js","./supabase-N0Uh3Xw6.js","./style-BaZo80h_.css","./index-DR8q-s95.js"])))=>i.map(i=>d[i]);
import{r as q,a as U,s as H,b as u,c as f}from"./supabase-N0Uh3Xw6.js";/* empty css              */const V="modulepreload",M=function(e,t){return new URL(e,t).href},S={},j=function(t,a,r){let d=Promise.resolve();if(a&&a.length>0){let i=function(o){return Promise.all(o.map(g=>Promise.resolve(g).then(p=>({status:"fulfilled",value:p}),p=>({status:"rejected",reason:p}))))};const n=document.getElementsByTagName("link"),l=document.querySelector("meta[property=csp-nonce]"),c=(l==null?void 0:l.nonce)||(l==null?void 0:l.getAttribute("nonce"));d=i(a.map(o=>{if(o=M(o,r),o in S)return;S[o]=!0;const g=o.endsWith(".css"),p=g?'[rel="stylesheet"]':"";if(!!r)for(let x=n.length-1;x>=0;x--){const y=n[x];if(y.href===o&&(!g||y.rel==="stylesheet"))return}else if(document.querySelector(`link[href="${o}"]${p}`))return;const b=document.createElement("link");if(b.rel=g?"stylesheet":V,g||(b.as="script"),b.crossOrigin="",b.href=o,c&&b.setAttribute("nonce",c),document.head.appendChild(b),g)return new Promise((x,y)=>{b.addEventListener("load",x),b.addEventListener("error",()=>y(new Error(`Unable to preload CSS for ${o}`)))})}))}function s(i){const n=new Event("vite:preloadError",{cancelable:!0});if(n.payload=i,window.dispatchEvent(n),!n.defaultPrevented)throw i}return d.then(i=>{for(const n of i||[])n.status==="rejected"&&s(n.reason);return t().catch(s)})};typeof pdfjsLib<"u"?pdfjsLib.GlobalWorkerOptions.workerSrc="https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.worker.min.js":console.error("pdfjsLib did not load from CDN — PDF preview will show the fallback error state.");function R(){try{return JSON.parse(localStorage.getItem("al_session"))||null}catch{return null}}const k=["","Poor","Fair","Good","Very Good","Excellent"],F=5,N=()=>!!(window.Capacitor&&window.Capacitor.isNativePlatform&&window.Capacitor.isNativePlatform());function W(e){return new Promise((t,a)=>{const r=new FileReader;r.onloadend=()=>t(r.result.split(",")[1]),r.onerror=a,r.readAsDataURL(e)})}async function L(e){if(N())try{const{Browser:t}=await j(async()=>{const{Browser:a}=await import("./index-_lHnZJZJ.js");return{Browser:a}},__vite__mapDeps([0,1,2,3]),import.meta.url);await t.open({url:e});return}catch{}window.open(e,"_blank","noopener,noreferrer")}async function G(e,t){if(N())try{const{Filesystem:a,Directory:r}=await j(async()=>{const{Filesystem:n,Directory:l}=await import("./index-DR8q-s95.js");return{Filesystem:n,Directory:l}},__vite__mapDeps([4,1,2,3]),import.meta.url),s=await(await fetch(e)).blob(),i=await W(s);await a.writeFile({path:t,data:i,directory:r.Documents}),f.showToast("Downloaded to your device.","success");return}catch{f.showToast("Download failed, opening instead.","error"),L(e);return}window.open(e,"_blank","noopener,noreferrer")}let h=null,v=1;document.addEventListener("DOMContentLoaded",async()=>{var l,c;document.getElementById("app-header").innerHTML=q("notes"),document.getElementById("app-footer").innerHTML=U(),H();const t=new URLSearchParams(window.location.search).get("noteId"),a=R();if(!t){A();return}const{data:r,error:d}=await u.from("notes").select("*").eq("id",t).eq("is_active",!0).maybeSingle();if(O(),d||!r){A();return}const{data:s}=await u.from("ratings").select("rating").eq("note_id",t);if(s&&s.length>0){const o=s.reduce((g,p)=>g+Number(p.rating),0);r.avg_rating=(o/s.length).toFixed(2),r.rating_count=s.length}let i="Unknown Student";if(r.uploaded_by_id){const{data:o}=await u.from("profiles").select("full_name, institution_name").eq("user_id",r.uploaded_by_id).maybeSingle();o&&(i=o.full_name)}let n=null;if(a){const{data:o}=await u.from("ratings").select("id, rating").eq("user_id",a.id).eq("note_id",t).maybeSingle();n=o}Y(r,i,n,a),(l=document.getElementById("close-report-modal-btn"))==null||l.addEventListener("click",()=>{document.getElementById("report-modal").classList.add("hidden")}),(c=document.getElementById("report-note-form"))==null||c.addEventListener("submit",async o=>{if(o.preventDefault(),!a){f.showToast("Please sign in to report a note.","error");return}const g=document.getElementById("report-reason-select").value,p=document.getElementById("report-desc-input").value.trim(),{error:w}=await u.from("reports").insert({reporter_id:a.id,note_id:Number(t),reason:g,description:p||null});if(w){f.showToast("Failed to submit report: "+w.message,"error");return}f.showToast("Report submitted to moderators.","info"),document.getElementById("report-modal").classList.add("hidden")})});function O(){var e,t;(e=document.getElementById("pdf-skeleton"))==null||e.classList.add("hidden"),(t=document.getElementById("pdf-viewer-content"))==null||t.classList.remove("hidden")}function A(){O(),document.getElementById("pdf-viewer-content").innerHTML=`
    <div class="text-center py-20 bg-white dark:bg-gray-900 rounded-3xl border border-dashed border-gray-200 dark:border-gray-800 p-8 space-y-4 max-w-lg mx-auto">
      <div class="w-16 h-16 rounded-full bg-rose-50 dark:bg-rose-950/50 text-rose-600 flex items-center justify-center mx-auto">
        <span class="material-symbols-outlined text-3xl">picture_as_pdf</span>
      </div>
      <h2 class="text-xl font-bold text-gray-900 dark:text-white font-headline">PDF Document Not Found</h2>
      <p class="text-xs text-gray-500 dark:text-gray-400">The requested note could not be found in the repository.</p>
      <a href="./notes.html" class="inline-block px-5 py-2.5 bg-indigo-600 text-white text-xs font-bold rounded-xl shadow-md">
        Browse Academic Notes
      </a>
    </div>`}function Y(e,t,a,r){var w,b,x,y,I,B,D,P,C,T,$;const d=e.institution_type==="university",s=d?e.course||"—":e.class_name||"School",i=d?`${e.institution_name||"—"} · ${e.department||""}`:`${e.institution_name||"—"} · ${e.subject||""}`,n=parseFloat(e.avg_rating||0).toFixed(1),l=Array.isArray(e.tags)?e.tags:[];document.getElementById("pdf-header-actions").innerHTML=`
    <!-- Desktop -->
    <div class="hidden sm:flex items-center gap-2">
      <button id="rate-note-btn"
        class="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-white dark:bg-gray-900 border border-gray-200 dark:border-gray-800 text-xs font-bold text-amber-500 hover:bg-amber-50 dark:hover:bg-amber-950/30 transition-colors shadow-sm">
        <span class="material-symbols-outlined text-base" style="font-variation-settings:'FILL' 1">star</span>
        <span>${a?"Your Rating: "+a.rating+"★":"Rate This Note"}</span>
      </button>
      <button id="report-trigger-btn"
        class="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-white dark:bg-gray-900 border border-gray-200 dark:border-gray-800 text-xs font-bold text-rose-600 hover:bg-rose-50 transition-colors shadow-sm">
        <span class="material-symbols-outlined text-base">flag</span>
        <span>Report</span>
      </button>
      <a id="download-btn-desktop" href="${e.file_url}" target="_blank"
        class="inline-flex items-center gap-2 px-5 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold shadow-md transition-all">
        <span class="material-symbols-outlined text-base">download</span>
        <span>Download PDF</span>
      </a>
    </div>

    <!-- Mobile 3-dot -->
    <div class="relative sm:hidden">
      <button id="pdf-3dot-btn"
        class="p-2 rounded-xl bg-white dark:bg-gray-900 border border-gray-200 dark:border-gray-800 text-gray-700 dark:text-gray-200 hover:bg-gray-100 transition-colors">
        <span class="material-symbols-outlined text-xl">more_vert</span>
      </button>
      <div id="pdf-3dot-dropdown"
        class="hidden absolute right-0 top-10 z-30 w-52 bg-white dark:bg-gray-800 rounded-2xl border border-gray-100 dark:border-gray-700 shadow-xl py-2 text-xs font-semibold">
        <a id="download-btn-mobile" href="${e.file_url}" target="_blank"
          class="flex items-center gap-2.5 px-4 py-2.5 text-gray-800 dark:text-gray-200 hover:bg-indigo-50 dark:hover:bg-indigo-950/50 hover:text-indigo-600">
          <span class="material-symbols-outlined text-base">download</span> Download PDF
        </a>
        <button id="rate-note-btn-mobile"
          class="w-full flex items-center gap-2.5 px-4 py-2.5 text-amber-500 hover:bg-amber-50 dark:hover:bg-amber-950/50">
          <span class="material-symbols-outlined text-base" style="font-variation-settings:'FILL' 1">star</span>
          ${a?"Change Rating":"Rate This Note"}
        </button>
        <button id="share-btn-mobile"
          class="w-full flex items-center gap-2.5 px-4 py-2.5 text-gray-800 dark:text-gray-200 hover:bg-indigo-50 dark:hover:bg-indigo-950/50 hover:text-indigo-600">
          <span class="material-symbols-outlined text-base">share</span> Share Note
        </button>
        <button id="report-trigger-btn-mobile"
          class="w-full flex items-center gap-2.5 px-4 py-2.5 text-rose-600 hover:bg-rose-50 dark:hover:bg-rose-950/40">
          <span class="material-symbols-outlined text-base">flag</span> Report Issue
        </button>
      </div>
    </div>
  `,document.getElementById("pdf-viewer-content").innerHTML=`

    <!-- Note Meta Card -->
    <div class="bg-white dark:bg-gray-900 rounded-3xl p-5 sm:p-8 border border-gray-100 dark:border-gray-800 shadow-sm space-y-5">
      <div class="flex flex-col sm:flex-row sm:items-start justify-between gap-4">
        <div class="space-y-2 flex-1 min-w-0">
          <div class="flex flex-wrap items-center gap-2">
            <span class="px-3 py-1 rounded-xl bg-indigo-50 dark:bg-indigo-950/50 text-indigo-600 dark:text-indigo-400 text-xs font-bold">${s}</span>
            ${e.category?`<span class="text-xs text-gray-400 font-medium">${e.category}</span>`:""}
            <span class="flex items-center gap-0.5 text-xs font-bold text-amber-500">
              <span class="material-symbols-outlined text-sm" style="font-variation-settings:'FILL' 1">star</span>
              <span id="live-avg-rating">${n}</span>
              <span class="text-gray-400 font-normal">(${e.rating_count||0})</span>
            </span>
          </div>
          <h1 class="text-xl sm:text-2xl font-extrabold text-gray-900 dark:text-white font-headline break-words">${e.title}</h1>
          <p class="text-xs text-gray-500 dark:text-gray-400 font-medium flex items-center gap-1">
            <span class="material-symbols-outlined text-xs">${d?"school":"menu_book"}</span>
            ${i}
          </p>
        </div>

        <!-- Uploader info -->
        <div class="flex items-center gap-3 p-3 bg-gray-50 dark:bg-gray-800/50 rounded-2xl shrink-0 self-start">
          <div class="w-10 h-10 rounded-full bg-indigo-100 dark:bg-indigo-900/50 flex items-center justify-center text-indigo-600 font-extrabold text-lg">
            ${t.charAt(0).toUpperCase()}
          </div>
          <div class="text-xs">
            <span class="text-gray-400 block text-[10px]">Uploaded by</span>
            <span class="font-bold text-gray-900 dark:text-white block">${t}</span>
            <span class="text-[10px] text-gray-400">${new Date(e.created_at).toLocaleDateString("en-GB",{day:"2-digit",month:"short",year:"numeric"})}</span>
          </div>
        </div>
      </div>

      <!-- Stats grid -->
      <div class="grid grid-cols-2 sm:grid-cols-4 gap-3 pt-4 border-t border-gray-100 dark:border-gray-800 text-xs">
        <div class="bg-gray-50 dark:bg-gray-800/40 p-3 rounded-xl">
          <span class="text-gray-400 text-[10px] block">Downloads</span>
          <span class="font-bold text-gray-800 dark:text-gray-200 mt-0.5 block" id="live-download-count">${e.download_count||0}</span>
        </div>
        <div class="bg-gray-50 dark:bg-gray-800/40 p-3 rounded-xl">
          <span class="text-gray-400 text-[10px] block">Avg Rating</span>
          <span class="font-bold text-amber-500 mt-0.5 block">${n} / 5.0</span>
        </div>
        <div class="bg-gray-50 dark:bg-gray-800/40 p-3 rounded-xl">
          <span class="text-gray-400 text-[10px] block">Type</span>
          <span class="font-bold text-gray-800 dark:text-gray-200 mt-0.5 block">${d?"University":"School/College"}</span>
        </div>
        <div class="bg-gray-50 dark:bg-gray-800/40 p-3 rounded-xl">
          <span class="text-gray-400 text-[10px] block">Tags</span>
          <div class="flex flex-wrap gap-1 mt-0.5">
            ${l.slice(0,3).map(m=>`<span class="text-[10px] text-gray-500 dark:text-gray-400">#${m}</span>`).join(" ")}
          </div>
        </div>
      </div>

      ${e.description?`<p class="text-xs text-gray-600 dark:text-gray-300 leading-relaxed pt-3 border-t border-gray-100 dark:border-gray-800">${e.description}</p>`:""}
    </div>

    <!-- Bottom banner ad slot — ALWAYS visible (not gated behind download).
         Reserved space for a small banner ad tag; paste your ad network
         code where marked below. -->
    <div id="ad-slot-bottom" class="bg-white dark:bg-gray-900 rounded-2xl border border-dashed border-gray-200 dark:border-gray-800 min-h-[90px] flex flex-col items-center justify-center gap-1 py-4 px-4 text-center">
      <span class="material-symbols-outlined text-2xl text-gray-300 dark:text-gray-700">campaign</span>
      <span class="text-[10px] font-bold text-gray-400 dark:text-gray-600 uppercase tracking-wide">Advertisement</span>
      <!-- YOUR BANNER AD CODE HERE -->
    </div>

    <!-- PDF Viewer -->
    <div class="bg-white dark:bg-gray-900 rounded-3xl border border-gray-100 dark:border-gray-800 shadow-sm overflow-hidden">

      <!-- Toolbar -->
      <div class="bg-gray-100 dark:bg-gray-800 px-4 py-3 flex flex-wrap items-center justify-between gap-3 border-b border-gray-200 dark:border-gray-700 text-xs">
        <div class="flex items-center gap-2 min-w-0">
          <span class="material-symbols-outlined text-indigo-600 text-lg flex-shrink-0">picture_as_pdf</span>
          <span class="font-bold text-gray-800 dark:text-gray-200 truncate max-w-[160px] sm:max-w-xs">${e.title}.pdf</span>
        </div>
        <div class="flex items-center gap-2 flex-wrap">
          <a id="pdf-open-tab-link" href="${e.file_url}" target="_blank"
            class="px-3 py-1.5 rounded-lg bg-white dark:bg-gray-900 text-gray-700 dark:text-gray-200 font-bold hover:text-indigo-600 transition-colors shadow-sm flex items-center gap-1 text-xs">
            <span class="material-symbols-outlined text-sm">open_in_new</span>
            <span class="hidden sm:inline">Open in Full Tab</span>
            <span class="sm:hidden">Open</span>
          </a>
          <button id="download-and-show-ad"
            class="px-3.5 py-1.5 rounded-lg bg-indigo-600 hover:bg-indigo-700 text-white font-bold transition-all shadow-sm flex items-center gap-1 text-xs">
            <span class="material-symbols-outlined text-sm">download</span>
            <span>Download</span>
          </button>
        </div>
      </div>

      <!-- Canvas-rendered PDF (pdf.js) -->
      <div class="pdf-frame-wrap">
        <div id="pdf-loading-state" class="flex flex-col items-center justify-center gap-2 text-white/70 text-xs py-16 w-full">
          <span class="material-symbols-outlined text-2xl animate-spin">progress_activity</span>
          <span>PDF load hocche…</span>
        </div>
        <div id="pdf-render-area" class="hidden w-full flex justify-center"></div>
      </div>

      <!-- Pager -->
      <div class="bg-gray-100 dark:bg-gray-800 px-4 py-2.5 flex items-center justify-center gap-3 border-t border-b border-gray-200 dark:border-gray-700 text-xs">
        <button id="pdf-prev-page" disabled
          class="p-1.5 rounded-lg bg-white dark:bg-gray-900 border border-gray-200 dark:border-gray-700 disabled:opacity-40 transition-colors">
          <span class="material-symbols-outlined text-base">chevron_left</span>
        </button>
        <span class="font-bold text-gray-700 dark:text-gray-200">Page <span id="pdf-current-page">1</span> / <span id="pdf-total-pages">—</span></span>
        <button id="pdf-next-page" disabled
          class="p-1.5 rounded-lg bg-white dark:bg-gray-900 border border-gray-200 dark:border-gray-700 disabled:opacity-40 transition-colors">
          <span class="material-symbols-outlined text-base">chevron_right</span>
        </button>
      </div>

      <!-- Fallback links -->
      <div class="px-5 py-4 border-t border-gray-100 dark:border-gray-800 bg-gray-50 dark:bg-gray-800/40 text-center space-y-2">
        <p class="text-[11px] text-gray-400">If the viewer doesn't load, open or download the PDF directly:</p>
        <div class="flex justify-center gap-3 flex-wrap">
          <a id="fallback-open-pdf-link" href="${e.file_url}" target="_blank"
            class="px-4 py-2 bg-indigo-600 text-white text-xs font-bold rounded-xl hover:bg-indigo-700 inline-flex items-center gap-1.5">
            <span class="material-symbols-outlined text-sm">file_open</span> Open PDF
          </a>
          <a id="fallback-download-pdf-link" href="${e.file_url}" download target="_blank"
            class="px-4 py-2 bg-emerald-600 text-white text-xs font-bold rounded-xl hover:bg-emerald-700 inline-flex items-center gap-1.5">
            <span class="material-symbols-outlined text-sm">download</span> Download
          </a>
        </div>
      </div>
    </div>
  `;const c=()=>{document.getElementById("report-note-id").value=e.id,document.getElementById("report-note-title").value=e.title,document.getElementById("report-modal").classList.remove("hidden")};(w=document.getElementById("report-trigger-btn"))==null||w.addEventListener("click",c),(b=document.getElementById("report-trigger-btn-mobile"))==null||b.addEventListener("click",c);const o=()=>{if(!r){f.showToast("Please sign in to rate this note.","error");return}K(a)};(x=document.getElementById("rate-note-btn"))==null||x.addEventListener("click",o),(y=document.getElementById("rate-note-btn-mobile"))==null||y.addEventListener("click",o),(I=document.getElementById("share-btn-mobile"))==null||I.addEventListener("click",()=>{navigator.clipboard.writeText(window.location.href).then(()=>f.showToast("Link copied to clipboard!","success")).catch(()=>f.showToast(window.location.href,"info"))});const g=document.getElementById("pdf-3dot-btn"),p=document.getElementById("pdf-3dot-dropdown");g==null||g.addEventListener("click",m=>{m.stopPropagation(),p.classList.toggle("hidden")}),document.addEventListener("click",()=>p==null?void 0:p.classList.add("hidden")),(B=document.getElementById("pdf-open-tab-link"))==null||B.addEventListener("click",m=>{m.preventDefault(),L(e.file_url)}),(D=document.getElementById("fallback-open-pdf-link"))==null||D.addEventListener("click",m=>{m.preventDefault(),L(e.file_url)}),(P=document.getElementById("download-and-show-ad"))==null||P.addEventListener("click",()=>E(e)),(C=document.getElementById("download-btn-desktop"))==null||C.addEventListener("click",m=>{m.preventDefault(),E(e)}),(T=document.getElementById("download-btn-mobile"))==null||T.addEventListener("click",m=>{m.preventDefault(),E(e)}),($=document.getElementById("fallback-download-pdf-link"))==null||$.addEventListener("click",m=>{m.preventDefault(),E(e)}),z(e.file_url)}async function E(e){J();const{error:t}=await u.rpc("increment_note_downloads",{note_id:Number(e.id)});if(!t){const a=document.getElementById("live-download-count");a&&(a.textContent=(parseInt(a.textContent,10)||0)+1)}G(e.file_url,`${e.title}.pdf`)}async function z(e){const t=document.getElementById("pdf-loading-state"),a=document.getElementById("pdf-render-area"),r=document.getElementById("pdf-prev-page"),d=document.getElementById("pdf-next-page"),s=document.getElementById("pdf-total-pages");if(!(!t||!a)){if(typeof pdfjsLib>"u"){t.innerHTML=`
      <span class="material-symbols-outlined text-2xl text-rose-400">error</span>
      <span class="text-white/70">Viewer load korte problem hocche — niche-r "Open PDF" button use koro.</span>
    `;return}try{h=await pdfjsLib.getDocument(e).promise,s.textContent=h.numPages,t.classList.add("hidden"),a.classList.remove("hidden"),await _(1),r.disabled=!0,d.disabled=h.numPages<=1,r.addEventListener("click",()=>{v>1&&_(v-1)}),d.addEventListener("click",()=>{v<h.numPages&&_(v+1)})}catch{t.innerHTML=`
      <span class="material-symbols-outlined text-2xl text-rose-400">error</span>
      <span class="text-white/70">Viewer load korte problem hocche — niche-r "Open PDF" button use koro.</span>
    `}}}async function _(e){if(!h)return;const t=await h.getPage(e),a=document.getElementById("pdf-render-area"),r=a.clientWidth||700,d=t.getViewport({scale:1}),s=r/d.width,i=t.getViewport({scale:s});let n=document.getElementById("pdf-page-canvas");n||(n=document.createElement("canvas"),n.id="pdf-page-canvas",a.innerHTML="",a.appendChild(n));const l=n.getContext("2d");n.width=i.width,n.height=i.height,await t.render({canvasContext:l,viewport:i}).promise,v=e,document.getElementById("pdf-current-page").textContent=e,document.getElementById("pdf-prev-page").disabled=e<=1,document.getElementById("pdf-next-page").disabled=e>=h.numPages}function J(){const e=document.getElementById("ad-modal"),t=document.getElementById("ad-skip-btn"),a=document.getElementById("ad-countdown"),r=document.getElementById("ad-progress-bar");if(!e||!t||!a)return;let d=F;t.disabled=!0,t.textContent="Please wait…",a.textContent=d,e.classList.remove("hidden"),r&&(r.style.transition="none",r.style.width="0%",requestAnimationFrame(()=>{requestAnimationFrame(()=>{r.style.transition=`width ${F}s linear`,r.style.width="100%"})}));const s=setInterval(()=>{d-=1,d<=0?(clearInterval(s),t.disabled=!1,t.textContent="Skip Ad",a.textContent="0"):a.textContent=d},1e3);t.onclick=()=>{t.disabled||(clearInterval(s),e.classList.add("hidden"))}}function K(e){const t=document.getElementById("rating-modal"),a=document.querySelectorAll("#modal-star-rating .star-btn"),r=document.getElementById("rating-label"),d=document.getElementById("rating-submit-btn");let s=(e==null?void 0:e.rating)||0;a.forEach((i,n)=>{i.classList.toggle("filled",n<s)}),r.textContent=s?k[s]:"",d.disabled=s===0,a.forEach(i=>{const n=parseInt(i.dataset.value);i.addEventListener("mouseenter",()=>{a.forEach((l,c)=>l.classList.toggle("active",c<n)),r.textContent=k[n]}),i.addEventListener("mouseleave",()=>{a.forEach((l,c)=>{l.classList.remove("active"),l.classList.toggle("filled",c<s)}),r.textContent=s?k[s]:""}),i.addEventListener("click",()=>{s=n,d.disabled=!1,a.forEach((l,c)=>l.classList.toggle("filled",c<n)),r.textContent=k[n]})}),t.classList.remove("hidden"),document.getElementById("rating-cancel-btn").onclick=()=>t.classList.add("hidden"),d.onclick=null,d.addEventListener("click",async()=>{if(!s)return;d.disabled=!0,d.textContent="Submitting…";const i=R(),n=new URLSearchParams(window.location.search).get("noteId");let l;if(e){const{error:o}=await u.from("ratings").update({rating:s}).eq("id",e.id);l=o}else{const{error:o}=await u.from("ratings").insert({user_id:i.id,note_id:Number(n),rating:s});l=o}if(l){document.getElementById("rating-error").textContent=l.message,document.getElementById("rating-error").classList.remove("hidden"),d.disabled=!1,d.textContent="Submit Rating";return}await u.rpc("update_note_rating",{p_note_id:Number(n)});const{data:c}=await u.from("notes").select("avg_rating, rating_count").eq("id",n).maybeSingle();if(c){const o=document.getElementById("live-avg-rating");o&&(o.textContent=parseFloat(c.avg_rating).toFixed(1))}t.classList.add("hidden"),f.showToast("Thank you for rating this note!","success"),document.getElementById("rate-note-btn").querySelector("span:last-child").textContent=`Your Rating: ${s}★`},{once:!0})}export{j as _};
