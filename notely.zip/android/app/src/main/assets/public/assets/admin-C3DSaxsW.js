import{r as w,a as $,s as E,b as d}from"./supabase-N0Uh3Xw6.js";/* empty css              */function k(){try{return JSON.parse(localStorage.getItem("al_session"))||null}catch{return null}}document.addEventListener("DOMContentLoaded",async()=>{document.getElementById("app-header").innerHTML=w("admin"),document.getElementById("app-footer").innerHTML=$(),E();const n=k();if(!n){h();return}const{data:o,error:s}=await d.from("users").select("id, email, is_staff").eq("id",n.id).maybeSingle();if(s||!o||!o.is_staff){h();return}document.getElementById("access-denied").classList.add("hidden"),document.getElementById("admin-main").classList.remove("hidden"),document.getElementById("admin-email-label").textContent=o.email,L(),await l()});function h(){document.getElementById("access-denied").classList.remove("hidden"),document.getElementById("access-denied").classList.add("flex"),document.getElementById("admin-main").classList.add("hidden")}function L(){document.querySelectorAll(".tab-btn").forEach(n=>{n.addEventListener("click",()=>{var s;const o=n.dataset.tab;document.querySelectorAll(".tab-btn").forEach(e=>{e.classList.remove("active"),e.classList.add("text-gray-600","dark:text-gray-300")}),n.classList.add("active"),n.classList.remove("text-gray-600","dark:text-gray-300"),document.querySelectorAll(".tab-section").forEach(e=>e.classList.remove("active")),(s=document.getElementById(`tab-${o}`))==null||s.classList.add("active")})})}async function l(){const[{data:n},{data:o},{data:s},{data:e},{data:t},{data:a},{data:i},{data:c},{data:p}]=await Promise.all([d.from("reports").select("*").eq("status","pending").order("created_at",{ascending:!1}),d.from("notes").select("id, title, course, institution_name, institution_type, class_name, is_active, download_count, avg_rating, uploaded_by_id, created_at").order("created_at",{ascending:!1}),d.from("jobs").select("*").eq("is_active",!1).order("created_at",{ascending:!1}),d.from("jobs").select("id, posted_by_id").eq("is_active",!0),d.from("users").select("id, email, is_staff, is_active, date_joined").order("date_joined",{ascending:!1}),d.from("profiles").select("user_id, full_name, institution_name, institution_type"),d.from("notes").select("id",{count:"exact",head:!0}),d.from("jobs").select("posted_by_id, id").eq("is_active",!0),d.from("notes").select("uploaded_by_id, id")]),x={};(a||[]).forEach(r=>{x[r.user_id]=r});const u={};(c||[]).forEach(r=>{u[r.posted_by_id]=(u[r.posted_by_id]||0)+1});const g={};(p||[]).forEach(r=>{g[r.uploaded_by_id]=(g[r.uploaded_by_id]||0)+1});const f=[...new Set((n||[]).map(r=>r.reporter_id).filter(Boolean))];let y={};if(f.length){const{data:r}=await d.from("profiles").select("user_id, full_name").in("user_id",f);(r||[]).forEach(b=>{y[b.user_id]=b.full_name})}const v=[...new Set((n||[]).map(r=>r.note_id).filter(Boolean))];let _={};if(v.length){const{data:r}=await d.from("notes").select("id, title").in("id",v);(r||[]).forEach(b=>{_[b.id]=b.title})}document.getElementById("stat-reports").textContent=(n||[]).length,document.getElementById("stat-notes").textContent=(o||[]).length,document.getElementById("stat-jobs").textContent=(s||[]).length,document.getElementById("stat-users").textContent=(t||[]).length,document.getElementById("reports-count-badge").textContent=(n||[]).length,document.getElementById("jobs-pending-badge").textContent=(s||[]).length,S(n||[],_,y),q(s||[],x),I(o||[],x),B(t||[],x,g,u)}function S(n,o,s){const e=document.getElementById("reports-table-body");if(e){if(!n.length){e.innerHTML='<tr><td colspan="5" class="py-8 text-center text-gray-400 italic text-xs">No pending reports.</td></tr>';return}e.innerHTML=n.map(t=>{const a=o[t.note_id]||`Note #${t.note_id}`,i=s[t.reporter_id]||`User #${t.reporter_id}`,c=new Date(t.created_at).toLocaleDateString("en-GB",{day:"2-digit",month:"short",year:"numeric"});return`
      <tr>
        <td class="py-3 px-2 font-bold text-gray-900 dark:text-white max-w-[150px] truncate">${a}</td>
        <td class="py-3 px-2 text-rose-600 font-semibold text-[11px] max-w-[120px]">${t.reason}</td>
        <td class="py-3 px-2 text-gray-500 text-[11px]">${i}</td>
        <td class="py-3 px-2 text-gray-400 text-[11px] whitespace-nowrap">${c}</td>
        <td class="py-3 px-2 text-right space-x-2 whitespace-nowrap">
          <button class="dismiss-report-btn text-xs font-bold text-gray-500 hover:text-gray-800 dark:hover:text-white"
            data-id="${t.id}">Dismiss</button>
          <button class="hide-note-btn text-xs font-bold text-rose-600 hover:underline"
            data-id="${t.id}" data-note-id="${t.note_id}">Hide Note</button>
        </td>
      </tr>`}).join(""),e.querySelectorAll(".dismiss-report-btn").forEach(t=>{t.addEventListener("click",async()=>{const a=t.dataset.id;await d.from("reports").update({status:"dismissed",reviewed_at:new Date().toISOString()}).eq("id",a),m("Report dismissed.","info"),await l()})}),e.querySelectorAll(".hide-note-btn").forEach(t=>{t.addEventListener("click",async()=>{const{id:a,noteId:i}=t.dataset;await d.from("notes").update({is_active:!1}).eq("id",i),await d.from("reports").update({status:"resolved",reviewed_at:new Date().toISOString()}).eq("id",a),m("Note hidden and report resolved.","success"),await l()})})}}function q(n,o){const s=document.getElementById("admin-jobs-list");if(s){if(!n.length){s.innerHTML='<p class="text-xs text-gray-400 py-4 italic text-center">No pending job approvals.</p>';return}s.innerHTML=n.map(e=>{const t=o[e.posted_by_id],a=(t==null?void 0:t.full_name)||`User #${e.posted_by_id}`,i=(t==null?void 0:t.institution_name)||"—",c=e.job_type||"Full-time",p=e.location||"—",x=new Date(e.created_at).toLocaleDateString("en-GB",{day:"2-digit",month:"short",year:"numeric"});return`
      <div class="rounded-2xl border border-gray-100 dark:border-gray-800 bg-gray-50 dark:bg-gray-800/40 p-4 space-y-3">
        <div class="flex flex-col sm:flex-row sm:items-start justify-between gap-3">
          <div class="space-y-1 min-w-0">
            <div class="flex flex-wrap items-center gap-2">
              <span class="px-2 py-0.5 rounded bg-amber-50 dark:bg-amber-950/50 text-amber-700 dark:text-amber-400 text-[10px] font-bold uppercase">${c}</span>
              <span class="text-[10px] text-gray-400">Posted: ${x}</span>
            </div>
            <h3 class="font-bold text-gray-900 dark:text-white text-sm">${e.title}</h3>
            <p class="text-xs text-gray-500">${e.company} · ${p}</p>
            <p class="text-[11px] text-indigo-500">Posted by: ${a} (${i})</p>
          </div>
          <div class="flex gap-2 flex-shrink-0">
            <button class="approve-job-btn px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold rounded-xl transition-all"
              data-id="${e.id}">
              <span class="material-symbols-outlined text-sm align-middle">check</span> Approve
            </button>
            <button class="reject-job-btn px-4 py-2 bg-rose-50 dark:bg-rose-950/50 text-rose-600 text-xs font-bold rounded-xl hover:bg-rose-100 transition-all"
              data-id="${e.id}">
              <span class="material-symbols-outlined text-sm align-middle">close</span> Reject
            </button>
          </div>
        </div>
        <p class="text-xs text-gray-500 dark:text-gray-400 line-clamp-2">${e.description}</p>
        <a href="${e.apply_link}" target="_blank" class="text-[11px] text-indigo-500 hover:underline flex items-center gap-1">
          <span class="material-symbols-outlined text-xs">open_in_new</span>${e.apply_link}
        </a>
      </div>`}).join(""),s.querySelectorAll(".approve-job-btn").forEach(e=>{e.addEventListener("click",async()=>{await d.from("jobs").update({is_active:!0}).eq("id",e.dataset.id),m("Job approved and published!","success"),await l()})}),s.querySelectorAll(".reject-job-btn").forEach(e=>{e.addEventListener("click",async()=>{await d.from("jobs").delete().eq("id",e.dataset.id),m("Job rejected and removed.","info"),await l()})})}}function I(n,o){const s=document.getElementById("admin-notes-list");if(s){if(!n.length){s.innerHTML='<p class="text-xs text-gray-400 py-4 italic text-center">No notes uploaded yet.</p>';return}s.innerHTML=n.map(e=>{const t=o[e.uploaded_by_id],a=(t==null?void 0:t.full_name)||`User #${e.uploaded_by_id}`,i=e.institution_name||"—",c=e.institution_type==="university"?e.course||"—":e.class_name||"School",p=!e.is_active;return`
      <div class="flex items-center justify-between p-3 rounded-xl ${p?"bg-rose-50 dark:bg-rose-950/20 border border-rose-100 dark:border-rose-900/30":"bg-gray-50 dark:bg-gray-800/50"} text-xs gap-3">
        <div class="space-y-0.5 truncate flex-1 min-w-0">
          <div class="font-bold text-gray-900 dark:text-white truncate">${e.title}</div>
          <div class="text-[10px] text-gray-400">${c} · ${i} · by ${a}</div>
          <div class="text-[10px] text-gray-400">↓ ${e.download_count||0} downloads · ★ ${parseFloat(e.avg_rating||0).toFixed(1)}</div>
          ${p?'<span class="text-[10px] text-rose-500 font-bold">Hidden</span>':""}
        </div>
        <div class="flex gap-1.5 flex-shrink-0">
          ${p?`<button class="restore-note-btn px-2.5 py-1 bg-emerald-50 dark:bg-emerald-950/50 text-emerald-600 rounded-lg font-bold hover:bg-emerald-100 transition-colors text-[11px]" data-id="${e.id}">Restore</button>`:`<button class="hide-note-admin-btn px-2.5 py-1 bg-amber-50 dark:bg-amber-950/50 text-amber-600 rounded-lg font-bold hover:bg-amber-100 transition-colors text-[11px]" data-id="${e.id}">Hide</button>`}
          <button class="delete-note-admin-btn px-2.5 py-1 bg-rose-50 dark:bg-rose-950/50 text-rose-600 rounded-lg font-bold hover:bg-rose-100 transition-colors text-[11px]" data-id="${e.id}">Delete</button>
        </div>
      </div>`}).join(""),s.querySelectorAll(".hide-note-admin-btn").forEach(e=>{e.addEventListener("click",async()=>{await d.from("notes").update({is_active:!1}).eq("id",e.dataset.id),m("Note hidden.","info"),await l()})}),s.querySelectorAll(".restore-note-btn").forEach(e=>{e.addEventListener("click",async()=>{await d.from("notes").update({is_active:!0}).eq("id",e.dataset.id),m("Note restored.","success"),await l()})}),s.querySelectorAll(".delete-note-admin-btn").forEach(e=>{e.addEventListener("click",async()=>{confirm("Permanently delete this note? This cannot be undone.")&&(await d.from("notes").delete().eq("id",e.dataset.id),m("Note permanently deleted.","info"),await l())})})}}function B(n,o,s,e){const t=document.getElementById("users-table-body");if(t){if(!n.length){t.innerHTML='<tr><td colspan="6" class="py-6 text-center text-gray-400 italic text-xs">No registered users.</td></tr>';return}t.innerHTML=n.map(a=>{const i=o[a.id],c=(i==null?void 0:i.institution_name)||"—",p=s[a.id]||0,x=e[a.id]||0,u=new Date(a.date_joined).toLocaleDateString("en-GB",{day:"2-digit",month:"short",year:"numeric"});return`
      <tr>
        <td class="py-3 px-2 text-xs">
          <div class="font-bold text-gray-900 dark:text-white">${a.email}</div>
          <div class="text-[10px] text-gray-400">Joined: ${u}</div>
        </td>
        <td class="py-3 px-2 text-[11px] text-gray-500 max-w-[140px] truncate">${c}</td>
        <td class="py-3 px-2 text-center">
          <span class="px-2 py-0.5 rounded-lg bg-indigo-50 dark:bg-indigo-950/50 text-indigo-600 dark:text-indigo-400 text-[10px] font-bold">${p}</span>
        </td>
        <td class="py-3 px-2 text-center">
          <span class="px-2 py-0.5 rounded-lg bg-emerald-50 dark:bg-emerald-950/50 text-emerald-600 dark:text-emerald-400 text-[10px] font-bold">${x}</span>
        </td>
        <td class="py-3 px-2">
          <span class="px-2 py-0.5 rounded-full ${a.is_staff?"bg-amber-50 dark:bg-amber-950/50 text-amber-600 dark:text-amber-400":"bg-gray-100 dark:bg-gray-800 text-gray-500"} text-[10px] font-bold">
            ${a.is_staff?"Admin":"Student"}
          </span>
        </td>
        <td class="py-3 px-2 text-right space-x-2 whitespace-nowrap">
          <button class="toggle-staff-btn text-[11px] font-bold text-indigo-600 hover:underline"
            data-id="${a.id}" data-staff="${a.is_staff}">
            ${a.is_staff?"Demote":"Make Admin"}
          </button>
          <button class="toggle-active-btn text-[11px] font-bold ${a.is_active?"text-rose-500 hover:underline":"text-emerald-600 hover:underline"}"
            data-id="${a.id}" data-active="${a.is_active}">
            ${a.is_active?"Deactivate":"Activate"}
          </button>
        </td>
      </tr>`}).join(""),t.querySelectorAll(".toggle-staff-btn").forEach(a=>{a.addEventListener("click",async()=>{const i=a.dataset.staff==="true";await d.from("users").update({is_staff:!i}).eq("id",a.dataset.id),m(i?"Admin role removed.":"Admin role granted.","info"),await l()})}),t.querySelectorAll(".toggle-active-btn").forEach(a=>{a.addEventListener("click",async()=>{const i=a.dataset.active==="true";await d.from("users").update({is_active:!i}).eq("id",a.dataset.id),m(i?"User deactivated.":"User activated.","info"),await l()})})}}function m(n,o="info"){try{const{appStore:e}=window.__academiaStore||{};if(e!=null&&e.showToast){e.showToast(n,o);return}}catch{}const s=document.createElement("div");s.className=`fixed bottom-6 right-6 z-[200] px-4 py-3 rounded-2xl text-xs font-bold text-white shadow-xl transition-all
    ${o==="success"?"bg-emerald-600":o==="error"?"bg-rose-600":"bg-indigo-600"}`,s.textContent=n,document.body.appendChild(s),setTimeout(()=>s.remove(),3e3)}
