import{r as p,a as g,s as x,b as m,c as y}from"./supabase-N0Uh3Xw6.js";/* empty css              */document.addEventListener("DOMContentLoaded",async()=>{document.getElementById("app-header").innerHTML=p("home"),document.getElementById("app-footer").innerHTML=g(),x();const e=document.getElementById("hero-search-form");e&&e.addEventListener("submit",r=>{r.preventDefault();const t=document.getElementById("hero-search-input").value.trim();window.location.href=`./notes.html?search=${encodeURIComponent(t)}`}),await b(),u()});async function b(){const e=document.getElementById("recent-notes-container");if(!e)return;e.innerHTML=`
    <div class="col-span-full flex justify-center py-10">
      <div class="flex items-center gap-2 text-xs text-gray-400 dark:text-gray-500">
        <span class="material-symbols-outlined text-base animate-spin">progress_activity</span>
        Loading recent notes…
      </div>
    </div>`;const{data:r,error:t}=await m.from("notes").select("id, title, course, institution_name, institution_type, department, class_name, subject, tags, created_at, download_count, avg_rating").eq("is_active",!0).order("created_at",{ascending:!1}).limit(6);if(t){e.innerHTML=`
      <div class="col-span-full text-center text-xs text-red-500 py-8">
        Failed to load notes: ${t.message}
      </div>`;return}if(!r||r.length===0){e.innerHTML=`
      <div class="col-span-full text-center py-12 bg-white dark:bg-gray-900 rounded-3xl border border-dashed border-gray-200 dark:border-gray-800 p-8 space-y-3">
        <div class="w-12 h-12 rounded-full bg-indigo-50 dark:bg-indigo-950/50 text-indigo-600 dark:text-indigo-400 flex items-center justify-center mx-auto">
          <span class="material-symbols-outlined text-2xl">description</span>
        </div>
        <p class="text-xs text-gray-500 dark:text-gray-400 font-medium">No notes uploaded yet. Be the first student to contribute!</p>
        <a href="./notes.html?action=upload" class="inline-block px-4 py-2 bg-indigo-600 text-white text-xs font-bold rounded-xl shadow-md">
          Upload First Note
        </a>
      </div>`;return}e.innerHTML=r.map(a=>{const s=a.institution_type==="university",n=s?a.course||"—":a.class_name||"School",d=a.institution_name||"—",i=s?`Dept: ${a.department||"General"}`:`Subject: ${a.subject||"—"}`,o=Array.isArray(a.tags)?a.tags:[],l=parseFloat(a.avg_rating||0).toFixed(1);return`
      <div class="bg-white dark:bg-gray-900 rounded-2xl border border-gray-100 dark:border-gray-800 p-5 shadow-sm hover:shadow-md transition-all flex flex-col justify-between group">
        <div class="space-y-3">
          <div class="flex items-center justify-between">
            <span class="px-2.5 py-1 rounded-lg bg-indigo-50 dark:bg-indigo-950/50 text-indigo-600 dark:text-indigo-400 text-[11px] font-bold">
              ${n}
            </span>
            <div class="flex items-center gap-1 text-[11px] text-amber-500 font-bold">
              <span class="material-symbols-outlined text-sm" style="font-variation-settings:'FILL' 1">star</span>
              ${l}
            </div>
          </div>

          <h3 class="text-base font-bold text-gray-900 dark:text-white font-headline group-hover:text-indigo-600 dark:group-hover:text-indigo-400 transition-colors line-clamp-2">
            ${a.title}
          </h3>

          <div class="text-[11px] text-gray-500 dark:text-gray-400 space-y-0.5">
            <div class="font-medium text-gray-700 dark:text-gray-300 truncate flex items-center gap-1">
              <span class="material-symbols-outlined text-xs">${s?"school":"menu_book"}</span>
              ${d}
            </div>
            <div>${i}</div>
          </div>

          <div class="flex flex-wrap gap-1">
            ${o.slice(0,3).map(c=>`
              <span class="px-2 py-0.5 rounded-md bg-gray-100 dark:bg-gray-800 text-[10px] text-gray-600 dark:text-gray-300">#${c}</span>
            `).join("")}
          </div>
        </div>

        <div class="border-t border-gray-100 dark:border-gray-800 pt-4 mt-4 flex items-center justify-between">
          <div class="flex items-center gap-1 text-[11px] text-gray-400">
            <span class="material-symbols-outlined text-sm">download</span>
            <span>${a.download_count||0}</span>
          </div>
          <a href="./pdf-viewer.html?noteId=${a.id}"
            class="px-3 py-1.5 rounded-xl bg-indigo-50 dark:bg-indigo-950/50 text-indigo-600 dark:text-indigo-400 text-xs font-bold hover:bg-indigo-100 dark:hover:bg-indigo-900/60 transition-colors flex items-center gap-1">
            <span class="material-symbols-outlined text-sm">visibility</span>
            <span>View PDF</span>
          </a>
        </div>
      </div>`}).join("")}function u(){const e=document.getElementById("featured-jobs-container");if(!e)return;const r=y.getJobs().slice(0,4);if(r.length===0){e.innerHTML=`
      <div class="col-span-full text-center py-12 bg-white dark:bg-gray-900 rounded-3xl border border-dashed border-gray-200 dark:border-gray-800 p-8 space-y-3">
        <div class="w-12 h-12 rounded-full bg-emerald-50 dark:bg-emerald-950/50 text-emerald-600 dark:text-emerald-400 flex items-center justify-center mx-auto">
          <span class="material-symbols-outlined text-2xl">work</span>
        </div>
        <p class="text-xs text-gray-500 dark:text-gray-400 font-medium">No job postings currently available. Check back soon!</p>
        <a href="./jobs.html" class="inline-block px-4 py-2 bg-emerald-600 text-white text-xs font-bold rounded-xl shadow-md">
          Explore Jobs Page
        </a>
      </div>`;return}e.innerHTML=r.map(t=>`
    <div class="bg-white dark:bg-gray-900 rounded-2xl border border-gray-100 dark:border-gray-800 p-5 shadow-sm hover:shadow-md transition-all flex flex-col justify-between space-y-4">
      <div class="space-y-3">
        <div class="flex items-start gap-3">
          <img src="${t.companyLogo}" alt="${t.company}"
            class="w-10 h-10 rounded-xl object-cover bg-gray-50 border border-gray-200 dark:border-gray-800 shrink-0" />
          <div>
            <span class="px-2 py-0.5 rounded bg-emerald-50 dark:bg-emerald-950/50 text-emerald-700 dark:text-emerald-400 text-[10px] font-bold uppercase">
              ${t.jobType}
            </span>
            <h3 class="text-sm font-bold text-gray-900 dark:text-white font-headline mt-1 line-clamp-1">${t.title}</h3>
            <p class="text-xs font-semibold text-gray-600 dark:text-gray-300">${t.company} • ${t.location}</p>
          </div>
        </div>
      </div>
      <div class="border-t border-gray-100 dark:border-gray-800 pt-3 flex items-center justify-between text-xs">
        <span class="font-bold text-gray-900 dark:text-white">${t.salary}</span>
        <a href="./jobs.html" class="text-emerald-600 dark:text-emerald-400 font-bold hover:underline">Apply Now →</a>
      </div>
    </div>`).join("")}
