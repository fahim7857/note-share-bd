import{r as I,a as N,s as L,b as x,c as S,U as C}from"./supabase-N0Uh3Xw6.js";/* empty css              */function M(){try{return JSON.parse(localStorage.getItem("al_session"))||null}catch{return null}}document.addEventListener("DOMContentLoaded",async()=>{var n,a;document.getElementById("app-header").innerHTML=I("profile"),document.getElementById("app-footer").innerHTML=N(),L();const t=M();if(!t){U();return}const e=await _(t.id);!e||!e.is_profile_complete?(A(t.email),B(t,e)):w(t,e),(n=document.getElementById("close-edit-modal-btn"))==null||n.addEventListener("click",k),(a=document.getElementById("edit-profile-modal"))==null||a.addEventListener("click",s=>{s.target===s.currentTarget&&(e!=null&&e.is_profile_complete)&&k()})});async function _(t){const{data:e,error:n}=await x.from("profiles").select("*").eq("user_id",t).maybeSingle();return n?(console.error("[Profile fetch error]",n.message),null):e}async function T(t){const{data:e,error:n}=await x.from("notes").select("id, title, course, institution_name, institution_type, class_name, subject, category, tags, download_count, avg_rating, rating_count, created_at, is_active").eq("uploaded_by_id",t).order("created_at",{ascending:!1});return n?(console.error("[Uploads fetch error]",n.message),[]):e||[]}function U(){document.getElementById("profile-content").innerHTML=`
    <div class="text-center py-20 bg-white dark:bg-gray-900 rounded-3xl border border-dashed border-gray-200 dark:border-gray-800 p-8 space-y-5 max-w-lg mx-auto">
      <div class="w-16 h-16 rounded-full bg-indigo-50 dark:bg-indigo-950/50 text-indigo-600 dark:text-indigo-400 flex items-center justify-center mx-auto">
        <span class="material-symbols-outlined text-3xl">lock</span>
      </div>
      <div class="space-y-2">
        <h2 class="text-xl font-bold text-gray-900 dark:text-white font-headline">Please Sign In First</h2>
        <p class="text-xs text-gray-500 dark:text-gray-400 font-medium">You must be registered and signed in to access your student profile.</p>
      </div>
      <div class="flex items-center justify-center gap-3 pt-2">
        <a href="./login.html" class="px-6 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white font-bold rounded-xl text-xs shadow-md">Sign In Now</a>
        <a href="./register.html" class="px-6 py-2.5 bg-gray-100 hover:bg-gray-200 dark:bg-gray-800 text-gray-800 dark:text-gray-200 font-bold rounded-xl text-xs">Create Account</a>
      </div>
    </div>`}function A(t){document.getElementById("profile-content").innerHTML=`
    <div class="complete-banner">
      <span class="material-symbols-outlined text-4xl opacity-80">account_circle</span>
      <div>
        <p class="text-sm font-bold">Welcome, ${t}!</p>
        <p class="text-xs opacity-80 mt-0.5">Complete your profile to unlock all features — notes upload, job applications, and more.</p>
      </div>
    </div>`}function D(t){const e=t.institution_type==="university",n=e?t.course||"—":t.class_name||"School",a=e?t.institution_name||"—":`${t.institution_name||"—"} · ${t.subject||""}`,s=parseFloat(t.avg_rating||0).toFixed(1),r=Array.isArray(t.tags)?t.tags:[],o=!t.is_active;return`
    <div class="bg-white dark:bg-gray-900 rounded-2xl border ${o?"border-rose-200 dark:border-rose-900/50 opacity-60":"border-gray-100 dark:border-gray-800"} p-5 shadow-sm flex flex-col justify-between gap-3">
      <div class="space-y-2">
        <div class="flex items-center justify-between gap-2">
          <span class="px-2.5 py-1 rounded-lg bg-indigo-50 dark:bg-indigo-950/50 text-indigo-600 dark:text-indigo-400 text-[11px] font-bold truncate max-w-[120px]">${n}</span>
          <div class="flex items-center gap-1 text-[11px] font-bold text-amber-500 flex-shrink-0">
            <span class="material-symbols-outlined text-sm" style="font-variation-settings:'FILL' 1">star</span>
            ${s}
            <span class="text-gray-400 font-normal">(${t.rating_count||0})</span>
          </div>
        </div>

        <h3 class="text-sm font-bold text-gray-900 dark:text-white font-headline line-clamp-2">${t.title}</h3>

        <p class="text-[11px] text-gray-500 dark:text-gray-400 truncate flex items-center gap-1">
          <span class="material-symbols-outlined text-xs">${e?"school":"menu_book"}</span>
          ${a}
        </p>

        <div class="flex flex-wrap gap-1">
          ${r.slice(0,3).map(l=>`<span class="px-2 py-0.5 rounded-md bg-gray-100 dark:bg-gray-800 text-[10px] text-gray-600 dark:text-gray-300">#${l}</span>`).join("")}
        </div>

        ${o?'<span class="inline-flex items-center gap-1 text-[10px] font-bold text-rose-500"><span class="material-symbols-outlined text-xs">visibility_off</span> Hidden by moderator</span>':""}
      </div>

      <div class="border-t border-gray-100 dark:border-gray-800 pt-3 flex items-center justify-between text-[11px]">
        <div class="flex items-center gap-1 text-gray-400">
          <span class="material-symbols-outlined text-sm">download</span>
          <span>${t.download_count||0} downloads</span>
        </div>
        <a href="./pdf-viewer.html?noteId=${t.id}"
          class="px-3 py-1.5 rounded-xl bg-indigo-50 dark:bg-indigo-950/50 text-indigo-600 dark:text-indigo-400 font-bold hover:bg-indigo-100 transition-colors flex items-center gap-1 text-xs">
          <span class="material-symbols-outlined text-sm">visibility</span> View
        </a>
      </div>
    </div>`}async function w(t,e){var u,v;const n=document.getElementById("profile-content"),a=e.institution_type==="university",s=e.institution_name||"—",r=a?`${e.department||""} · ${e.batch||""}`:`${e.class_name||""} · ${e.group_name||""}`,o=await T(t.id);n.innerHTML=`
    <!-- Profile Card -->
    <div class="bg-white dark:bg-gray-900 rounded-3xl p-6 sm:p-8 border border-gray-100 dark:border-gray-800 shadow-sm space-y-6">
      <div class="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-6">
        <div class="flex items-center gap-5">
          <div class="w-20 h-20 rounded-3xl bg-indigo-100 dark:bg-indigo-900/50 flex items-center justify-center text-indigo-600 dark:text-indigo-400 text-3xl font-extrabold border-4 border-indigo-500/20 shadow-md">
            ${e.full_name.charAt(0).toUpperCase()}
          </div>
          <div class="space-y-1">
            <h1 class="text-2xl font-extrabold text-gray-900 dark:text-white font-headline">${e.full_name}</h1>
            <p class="text-xs font-semibold text-gray-500 dark:text-gray-400">${t.email}</p>
            <div class="flex items-center gap-2 text-xs text-indigo-600 dark:text-indigo-400 font-bold pt-0.5">
              <span class="material-symbols-outlined text-base">${a?"school":"menu_book"}</span>
              <span>${s}</span>
            </div>
            ${r.trim()!=="·"?`<p class="text-[11px] text-gray-400">${r}</p>`:""}
          </div>
        </div>
        <div class="flex items-center gap-2 flex-wrap">
          <button id="open-edit-profile-btn"
            class="px-5 py-2.5 bg-indigo-50 dark:bg-indigo-950/50 text-indigo-600 dark:text-indigo-400 hover:bg-indigo-100 font-bold rounded-2xl text-xs flex items-center gap-2 transition-all">
            <span class="material-symbols-outlined text-base">edit</span> Edit Profile
          </button>
          <button id="open-delete-account-btn"
            class="px-5 py-2.5 bg-rose-50 dark:bg-rose-950/30 text-rose-600 dark:text-rose-400 hover:bg-rose-100 dark:hover:bg-rose-950/50 font-bold rounded-2xl text-xs flex items-center gap-2 transition-all border border-rose-200 dark:border-rose-900/50">
            <span class="material-symbols-outlined text-base">delete_forever</span> Delete Account
          </button>
        </div>
      </div>

      <!-- Info Grid -->
      <div class="grid grid-cols-2 sm:grid-cols-4 gap-4 pt-4 border-t border-gray-100 dark:border-gray-800 text-xs">
        ${a?`
          <div class="bg-gray-50 dark:bg-gray-800/40 p-3.5 rounded-2xl">
            <span class="text-gray-400 text-[11px] block">Department</span>
            <span class="font-bold text-gray-800 dark:text-gray-200 mt-0.5 block truncate">${e.department||"N/A"}</span>
          </div>
          <div class="bg-gray-50 dark:bg-gray-800/40 p-3.5 rounded-2xl">
            <span class="text-gray-400 text-[11px] block">Batch</span>
            <span class="font-bold text-gray-800 dark:text-gray-200 mt-0.5 block">${e.batch||"N/A"}</span>
          </div>
          <div class="bg-gray-50 dark:bg-gray-800/40 p-3.5 rounded-2xl">
            <span class="text-gray-400 text-[11px] block">Registration No</span>
            <span class="font-bold text-gray-800 dark:text-gray-200 mt-0.5 block">${e.reg_no||"N/A"}</span>
          </div>
        `:`
          <div class="bg-gray-50 dark:bg-gray-800/40 p-3.5 rounded-2xl">
            <span class="text-gray-400 text-[11px] block">Class</span>
            <span class="font-bold text-gray-800 dark:text-gray-200 mt-0.5 block">${e.class_name||"N/A"}</span>
          </div>
          <div class="bg-gray-50 dark:bg-gray-800/40 p-3.5 rounded-2xl">
            <span class="text-gray-400 text-[11px] block">Group</span>
            <span class="font-bold text-gray-800 dark:text-gray-200 mt-0.5 block">${e.group_name||"N/A"}</span>
          </div>
        `}
        <div class="bg-gray-50 dark:bg-gray-800/40 p-3.5 rounded-2xl">
          <span class="text-gray-400 text-[11px] block">Type</span>
          <span class="font-bold text-gray-800 dark:text-gray-200 mt-0.5 block">${a?"University":"School / College"}</span>
        </div>
        <div class="bg-gray-50 dark:bg-gray-800/40 p-3.5 rounded-2xl">
          <span class="text-gray-400 text-[11px] block">Total Uploads</span>
          <span class="font-bold text-gray-800 dark:text-gray-200 mt-0.5 block">${o.length}</span>
        </div>
      </div>

      ${e.bio?`<p class="text-xs text-gray-600 dark:text-gray-300 italic pt-2">"${e.bio}"</p>`:""}
    </div>

    <!-- Tabs -->
    <div class="space-y-6">
      <div class="flex border-b border-gray-200 dark:border-gray-800 gap-6 text-sm font-bold">
        <button id="tab-uploads-btn" class="pb-3 border-b-2 border-indigo-600 text-indigo-600 dark:text-indigo-400 flex items-center gap-2">
          <span class="material-symbols-outlined text-lg">upload_file</span>
          <span>My Uploads (${o.length})</span>
        </button>
        <button id="tab-saved-btn" class="pb-3 text-gray-400 hover:text-gray-600 dark:hover:text-gray-200 flex items-center gap-2">
          <span class="material-symbols-outlined text-lg">bookmark</span>
          <span>Saved Notes</span>
        </button>
      </div>

      <!-- My Uploads (default active) -->
      <div id="uploaded-notes-section">
        ${o.length===0?`<div class="py-12 text-center bg-white dark:bg-gray-900 rounded-3xl border border-dashed border-gray-200 dark:border-gray-800 p-8 space-y-3">
               <span class="material-symbols-outlined text-4xl text-gray-300 dark:text-gray-600">upload_file</span>
               <p class="text-xs text-gray-500 dark:text-gray-400 font-medium">You haven't uploaded any notes yet.</p>
               <a href="./notes.html?action=upload" class="inline-block px-4 py-2 bg-indigo-600 text-white text-xs font-bold rounded-xl shadow-md">Upload Your First Note</a>
             </div>`:`<div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">${o.map(D).join("")}</div>`}
      </div>

      <!-- Saved Notes (hidden by default) -->
      <div id="saved-notes-section" class="hidden">
        <div class="py-12 text-center bg-white dark:bg-gray-900 rounded-3xl border border-dashed border-gray-200 dark:border-gray-800 p-8 space-y-2">
          <span class="material-symbols-outlined text-4xl text-gray-300 dark:text-gray-600">bookmark</span>
          <p class="text-xs text-gray-500 dark:text-gray-400 font-medium">No saved notes yet. Bookmark notes while browsing!</p>
          <a href="./notes.html" class="inline-block text-xs font-bold text-indigo-600 hover:underline">Explore Academic Notes</a>
        </div>
      </div>
    </div>
  `,(u=document.getElementById("open-edit-profile-btn"))==null||u.addEventListener("click",()=>{document.getElementById("modal-title").textContent="Edit Profile",B(t,e)}),(v=document.getElementById("open-delete-account-btn"))==null||v.addEventListener("click",()=>{const d=document.getElementById("delete-account-modal"),i=document.getElementById("delete-confirm-input"),m=document.getElementById("delete-confirm-error");i&&(i.value=""),m&&m.classList.add("hidden"),d.classList.remove("hidden"),d.classList.add("flex"),setTimeout(()=>i==null?void 0:i.focus(),100)}),H(t);const l=document.getElementById("tab-uploads-btn"),g=document.getElementById("tab-saved-btn"),c=document.getElementById("uploaded-notes-section"),y=document.getElementById("saved-notes-section"),b="pb-3 border-b-2 border-indigo-600 text-indigo-600 dark:text-indigo-400 flex items-center gap-2 font-bold",h="pb-3 text-gray-400 hover:text-gray-600 dark:hover:text-gray-200 flex items-center gap-2 font-medium";l==null||l.addEventListener("click",()=>{l.className=b,g.className=h,c.classList.remove("hidden"),y.classList.add("hidden")}),g==null||g.addEventListener("click",()=>{g.className=b,l.className=h,y.classList.remove("hidden"),c.classList.add("hidden")})}function B(t,e=null){document.getElementById("edit-profile-modal").classList.remove("hidden"),e&&(document.getElementById("profile-name-input").value=e.full_name||"",document.getElementById("profile-bio-input").value=e.bio||"",document.getElementById("profile-dept-input").value=e.department||"",document.getElementById("profile-batch-input").value=e.batch||"",document.getElementById("profile-reg-input").value=e.reg_no||"",document.getElementById("profile-school-name-input").value=e.institution_name||"",document.getElementById("profile-class-input").value=e.class_name||"",document.getElementById("profile-group-input").value=e.group_name||"",e.institution_type&&(f(e.institution_type),e.institution_type==="university"&&(document.getElementById("profile-univ-input").value=e.institution_name||""))),j(t,e)}function k(){document.getElementById("edit-profile-modal").classList.add("hidden")}function f(t){document.getElementById("institution-type-val").value=t;const e=document.getElementById("btn-university"),n=document.getElementById("btn-school"),a=document.getElementById("section-university"),s=document.getElementById("section-school");t==="university"?(e.classList.add("selected"),n.classList.remove("selected"),a.classList.add("active"),s.classList.remove("active")):(n.classList.add("selected"),e.classList.remove("selected"),s.classList.add("active"),a.classList.remove("active"))}function E(){const t=document.getElementById("profile-univ-input"),e=document.getElementById("univ-dropdown");if(!t||!e)return;let n=-1;t.addEventListener("input",()=>{const a=t.value.trim().toLowerCase();if(e.innerHTML="",n=-1,!a){e.classList.remove("open");return}const s=C.filter(r=>r.toLowerCase().includes(a)).slice(0,10);if(!s.length){e.classList.remove("open");return}s.forEach(r=>{const o=document.createElement("div");o.className="autocomplete-item",o.textContent=r,o.addEventListener("mousedown",l=>{l.preventDefault(),t.value=r,e.classList.remove("open")}),e.appendChild(o)}),e.classList.add("open")}),t.addEventListener("keydown",a=>{const s=e.querySelectorAll(".autocomplete-item");if(s.length){if(a.key==="ArrowDown")a.preventDefault(),n=Math.min(n+1,s.length-1);else if(a.key==="ArrowUp")a.preventDefault(),n=Math.max(n-1,0);else if(a.key==="Enter"&&n>=0){a.preventDefault(),t.value=s[n].textContent,e.classList.remove("open");return}else if(a.key==="Escape"){e.classList.remove("open");return}s.forEach((r,o)=>r.classList.toggle("active",o===n)),n>=0&&(t.value=s[n].textContent)}}),document.addEventListener("click",a=>{!t.contains(a.target)&&!e.contains(a.target)&&e.classList.remove("open")})}function j(t,e){var s,r,o,l;(s=document.getElementById("btn-university"))==null||s.addEventListener("click",()=>f("university")),(r=document.getElementById("btn-school"))==null||r.addEventListener("click",()=>f("school_college")),E();const n=document.getElementById("edit-profile-form");document.getElementById("profile-form-error");const a=n.cloneNode(!0);n.parentNode.replaceChild(a,n),(o=document.getElementById("btn-university"))==null||o.addEventListener("click",()=>f("university")),(l=document.getElementById("btn-school"))==null||l.addEventListener("click",()=>f("school_college")),E(),document.getElementById("edit-profile-form").addEventListener("submit",async g=>{g.preventDefault();const c=document.getElementById("profile-form-error");c.classList.add("hidden");const y=document.getElementById("institution-type-val").value,b=document.getElementById("profile-name-input").value.trim(),h=document.getElementById("profile-bio-input").value.trim();if(!b){p(c,"Full name is required.");return}if(!y){p(c,"Please select University or School/College.");return}let u={user_id:t.id,full_name:b,bio:h||null,institution_type:y,is_profile_complete:!0};if(y==="university"){const d=document.getElementById("profile-univ-input").value.trim(),i=document.getElementById("profile-dept-input").value.trim(),m=document.getElementById("profile-batch-input").value.trim(),$=document.getElementById("profile-reg-input").value.trim();if(!d){p(c,"Please enter your university name.");return}if(!i){p(c,"Department is required.");return}if(!m){p(c,"Batch / Year is required.");return}u={...u,institution_name:d,university_id:null,department:i,batch:m,reg_no:$||null,class_name:null,group_name:null}}else{const d=document.getElementById("profile-school-name-input").value.trim(),i=document.getElementById("profile-class-input").value,m=document.getElementById("profile-group-input").value;if(!d){p(c,"Please enter your school/college name.");return}if(!i){p(c,"Please select your class.");return}if(!m){p(c,"Please select your group.");return}u={...u,institution_name:d,university_id:null,department:null,batch:null,reg_no:null,class_name:i,group_name:m}}const v=document.getElementById("profile-save-btn");v.disabled=!0,v.textContent="Saving…";try{let d;if(e){const{error:m}=await x.from("profiles").update(u).eq("user_id",t.id);d=m}else{const{error:m}=await x.from("profiles").insert(u);d=m}if(d)throw new Error(d.message);S.showToast("Profile saved successfully!","success"),k();const i=await _(t.id);await w(t,i),document.getElementById("app-header").innerHTML=I("profile"),L()}catch(d){console.error("[Profile save error]",d),p(document.getElementById("profile-form-error"),d.message||"Something went wrong.")}finally{const d=document.getElementById("profile-save-btn");d&&(d.disabled=!1,d.textContent="Save Profile")}})}function p(t,e){t.textContent=e,t.classList.remove("hidden")}function H(t){const e=document.getElementById("delete-account-modal"),n=document.getElementById("delete-confirm-input"),a=document.getElementById("delete-confirm-error"),s=document.getElementById("delete-cancel-btn"),r=document.getElementById("delete-confirm-btn");e&&(s==null||s.addEventListener("click",()=>{e.classList.add("hidden"),e.classList.remove("flex"),n&&(n.value=""),a&&a.classList.add("hidden")}),e.addEventListener("click",o=>{o.target===e&&(e.classList.add("hidden"),e.classList.remove("flex"),n&&(n.value=""),a&&a.classList.add("hidden"))}),r==null||r.addEventListener("click",async()=>{if(!n||n.value.trim()!=="DELETE"){a==null||a.classList.remove("hidden"),n==null||n.focus();return}r.disabled=!0,r.textContent="Deleting…";try{await x.from("profiles").delete().eq("user_id",t.id);const{error:o}=await x.from("users").delete().eq("id",t.id);if(o)throw new Error(o.message);localStorage.removeItem("al_session"),window.location.href="./index.html"}catch(o){console.error("[Delete account error]",o),a.textContent="Something went wrong: "+(o.message||"Please try again."),a.classList.remove("hidden"),r.disabled=!1,r.innerHTML='<span class="material-symbols-outlined text-sm">delete_forever</span> Delete Forever'}}))}
