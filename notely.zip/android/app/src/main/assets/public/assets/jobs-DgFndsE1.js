import{r as q,a as A,s as _,c as b,b as L}from"./supabase-N0Uh3Xw6.js";/* empty css              */function E(){try{return JSON.parse(localStorage.getItem("al_session"))||null}catch{return null}}document.addEventListener("DOMContentLoaded",async()=>{var i,u,m,c,p;document.getElementById("app-header").innerHTML=q("jobs"),document.getElementById("app-footer").innerHTML=A(),_(),await v(),(i=document.getElementById("jobs-search-input"))==null||i.addEventListener("input",v),(u=document.getElementById("jobs-type-filter"))==null||u.addEventListener("change",v);const t=document.getElementById("post-job-modal"),r=document.getElementById("post-job-form"),o=document.getElementById("post-login-notice");(m=document.getElementById("open-post-job-modal-btn"))==null||m.addEventListener("click",()=>{E()?(r.classList.remove("hidden"),o.classList.add("hidden")):(r.classList.add("hidden"),o.classList.remove("hidden")),t.classList.remove("hidden")}),(c=document.getElementById("close-post-job-modal-btn"))==null||c.addEventListener("click",()=>{t.classList.add("hidden"),T()}),(p=document.getElementById("job-detail-modal"))==null||p.addEventListener("click",d=>{d.target===d.currentTarget&&d.currentTarget.classList.add("hidden")}),r&&r.addEventListener("submit",async d=>{d.preventDefault();const e=E();if(!e){b.showToast("Please sign in to post a job.","error");return}const a=document.getElementById("job-form-error"),n=document.getElementById("job-submit-btn");a.classList.add("hidden");const s=document.getElementById("job-title-input").value.trim(),l=document.getElementById("job-company-input").value.trim(),x=document.getElementById("job-location-input").value.trim(),y=document.getElementById("job-type-input").value,f=document.getElementById("job-salary-input").value.trim(),h=document.getElementById("job-url-input").value.trim(),j=document.getElementById("job-deadline-input").value.trim(),B=document.getElementById("job-reqs-input").value,k=document.getElementById("job-desc-input").value.trim();if(!s){g(a,"Job title is required.");return}if(!l){g(a,"Company name is required.");return}if(!x){g(a,"Location is required.");return}if(!h){g(a,"Application URL is required.");return}if(!k){g(a,"Job description is required.");return}const $=B.split(",").map(I=>I.trim()).filter(Boolean);n.disabled=!0,n.textContent="Submitting…";const{error:w}=await L.from("jobs").insert({title:s,company:l,description:k,apply_link:h,posted_by_id:e.id,location:x,job_type:y,salary:f||null,deadline:j||null,requirements:$,is_active:!1});if(w){g(a,"Failed to submit: "+w.message),n.disabled=!1,n.textContent="Submit for Admin Approval";return}b.showToast("Job submitted! It will appear after admin approval.","success"),r.reset(),t.classList.add("hidden"),n.disabled=!1,n.textContent="Submit for Admin Approval"})});async function v(){var p,d;const t=document.getElementById("jobs-grid");if(!t)return;const r=((p=document.getElementById("jobs-search-input"))==null?void 0:p.value.toLowerCase())||"",o=((d=document.getElementById("jobs-type-filter"))==null?void 0:d.value)||"";let i=L.from("jobs").select("*").eq("is_active",!0).order("created_at",{ascending:!1});o&&(i=i.eq("job_type",o));const{data:u,error:m}=await i;if(m){t.innerHTML=`
      <div class="col-span-full text-center text-xs text-red-500 py-8">
        Failed to load jobs: ${m.message}
      </div>`;return}const c=(u||[]).filter(e=>r?[e.title,e.company,e.location||""].join(" ").toLowerCase().includes(r):!0);if(c.length===0){t.innerHTML=`
      <div class="col-span-full text-center py-16 bg-white dark:bg-gray-900 rounded-3xl border border-dashed border-gray-200 dark:border-gray-800 p-8 space-y-4">
        <div class="w-16 h-16 rounded-full bg-emerald-50 dark:bg-emerald-950/50 text-emerald-600 dark:text-emerald-400 flex items-center justify-center mx-auto">
          <span class="material-symbols-outlined text-3xl">work_off</span>
        </div>
        <div class="space-y-1">
          <h3 class="text-base font-bold text-gray-900 dark:text-white font-headline">No Active Jobs Found</h3>
          <p class="text-xs text-gray-500 dark:text-gray-400 max-w-sm mx-auto font-medium">
            ${r?"Try adjusting your search or filters.":"Be the first to post a new job vacancy!"}
          </p>
        </div>
      </div>`;return}t.innerHTML=c.map(e=>{const a=Array.isArray(e.requirements)?e.requirements:[],n=e.job_type||"Full-time",s=e.location||"Bangladesh",l=e.salary||"Negotiable",x=e.deadline||"Open",y=new Date(e.created_at).toLocaleDateString("en-GB",{day:"2-digit",month:"short",year:"numeric"});return`
      <div class="bg-white dark:bg-gray-900 rounded-2xl border border-gray-100 dark:border-gray-800 p-5 shadow-sm hover:shadow-md transition-all flex flex-col justify-between gap-4">
        <div class="space-y-3">
          <div class="flex items-start justify-between gap-2">
            <div class="flex items-start gap-3 min-w-0">
              <!-- Company initial avatar -->
              <div class="w-11 h-11 rounded-xl bg-emerald-50 dark:bg-emerald-900/30 flex items-center justify-center text-emerald-600 dark:text-emerald-400 font-extrabold text-lg flex-shrink-0 border border-emerald-100 dark:border-emerald-900/50">
                ${e.company.charAt(0).toUpperCase()}
              </div>
              <div class="min-w-0">
                <span class="px-2 py-0.5 rounded bg-emerald-50 dark:bg-emerald-950/50 text-emerald-700 dark:text-emerald-400 text-[10px] font-bold uppercase">
                  ${n}
                </span>
                <h3 class="text-base font-bold text-gray-900 dark:text-white font-headline mt-1 line-clamp-1">${e.title}</h3>
                <p class="text-xs font-semibold text-gray-600 dark:text-gray-300 truncate">${e.company} · ${s}</p>
              </div>
            </div>

            <!-- 3-dot menu -->
            <div class="relative flex-shrink-0">
              <button class="job-3dot-btn p-1.5 rounded-xl text-gray-500 hover:text-gray-900 dark:text-gray-400 dark:hover:text-white bg-gray-50 dark:bg-gray-800 hover:bg-gray-100 dark:hover:bg-gray-700 transition-colors"
                data-id="${e.id}">
                <span class="material-symbols-outlined text-lg">more_vert</span>
              </button>
              <div id="job-menu-${e.id}" class="job-menu-dropdown hidden absolute right-0 top-9 z-30 w-48 bg-white dark:bg-gray-800 rounded-2xl border border-gray-100 dark:border-gray-700 shadow-xl py-1.5 text-xs font-semibold">
                <button class="view-job-btn w-full flex items-center gap-2.5 px-3.5 py-2 text-gray-700 dark:text-gray-200 hover:bg-emerald-50 dark:hover:bg-emerald-950/50 hover:text-emerald-600"
                  data-id="${e.id}">
                  <span class="material-symbols-outlined text-base">info</span> View Details
                </button>
                <a href="${e.apply_link}" target="_blank" rel="noopener noreferrer"
                  class="flex items-center gap-2.5 px-3.5 py-2 text-gray-700 dark:text-gray-200 hover:bg-emerald-50 dark:hover:bg-emerald-950/50 hover:text-emerald-600">
                  <span class="material-symbols-outlined text-base">open_in_new</span> Apply Externally
                </a>
                <button class="share-job-btn w-full flex items-center gap-2.5 px-3.5 py-2 text-gray-700 dark:text-gray-200 hover:bg-indigo-50 dark:hover:bg-indigo-950/50 hover:text-indigo-600"
                  data-id="${e.id}">
                  <span class="material-symbols-outlined text-base">share</span> Share Job
                </button>
              </div>
            </div>
          </div>

          <p class="text-xs text-gray-500 dark:text-gray-400 line-clamp-2">${e.description}</p>

          <!-- Requirements tags -->
          ${a.length?`
            <div class="flex flex-wrap gap-1">
              ${a.slice(0,4).map(f=>`
                <span class="px-2 py-0.5 rounded bg-gray-100 dark:bg-gray-800 text-[10px] text-gray-600 dark:text-gray-300">• ${f}</span>
              `).join("")}
              ${a.length>4?`<span class="text-[10px] text-gray-400">+${a.length-4} more</span>`:""}
            </div>
          `:""}
        </div>

        <div class="border-t border-gray-100 dark:border-gray-800 pt-4 flex items-center justify-between gap-3 flex-wrap">
          <div class="space-y-0.5">
            <div class="text-xs font-bold text-gray-900 dark:text-white">${l}</div>
            <div class="text-[10px] text-gray-400 flex items-center gap-1">
              <span class="material-symbols-outlined text-xs">schedule</span>
              Deadline: ${x}
            </div>
            <div class="text-[10px] text-gray-400">Posted: ${y}</div>
          </div>
          <button class="view-job-btn px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-xl shadow-sm transition-all text-xs flex items-center gap-1"
            data-id="${e.id}">
            <span class="material-symbols-outlined text-sm">visibility</span>
            View Details
          </button>
        </div>
      </div>`}).join(""),document.querySelectorAll(".job-3dot-btn").forEach(e=>{e.addEventListener("click",a=>{a.stopPropagation();const n=e.getAttribute("data-id"),s=document.getElementById(`job-menu-${n}`);document.querySelectorAll(".job-menu-dropdown").forEach(l=>{l!==s&&l.classList.add("hidden")}),s==null||s.classList.toggle("hidden")})}),document.addEventListener("click",()=>{document.querySelectorAll(".job-menu-dropdown").forEach(e=>e.classList.add("hidden"))}),document.querySelectorAll(".view-job-btn").forEach(e=>{e.addEventListener("click",a=>{a.stopPropagation();const n=e.getAttribute("data-id"),s=c.find(l=>String(l.id)===String(n));s&&S(s)})}),document.querySelectorAll(".share-job-btn").forEach(e=>{e.addEventListener("click",a=>{a.stopPropagation();const n=e.getAttribute("data-id"),s=`${window.location.origin}/jobs.html?jobId=${n}`;navigator.clipboard.writeText(s).then(()=>b.showToast("Job link copied!","success")).catch(()=>b.showToast("Link: "+s,"info"))})})}function S(t){var d;const r=document.getElementById("job-detail-modal"),o=document.getElementById("job-detail-content"),i=Array.isArray(t.requirements)?t.requirements:[],u=t.job_type||"Full-time",m=t.location||"Bangladesh",c=t.salary||"Negotiable",p=t.deadline||"Open";o.innerHTML=`
    <div class="flex items-center justify-between border-b border-gray-100 dark:border-gray-800 pb-3">
      <div class="flex flex-wrap items-center gap-2">
        <span class="px-2 py-0.5 rounded bg-emerald-50 dark:bg-emerald-950/50 text-emerald-700 dark:text-emerald-400 text-xs font-bold uppercase">${u}</span>
        <span class="text-xs text-gray-400">Deadline: ${p}</span>
      </div>
      <button id="close-job-modal-btn" class="p-1 rounded-lg text-gray-400 hover:bg-gray-100 dark:hover:bg-gray-800 flex-shrink-0">
        <span class="material-symbols-outlined text-xl">close</span>
      </button>
    </div>

    <div class="flex items-start gap-4">
      <div class="w-14 h-14 rounded-2xl bg-emerald-50 dark:bg-emerald-900/30 flex items-center justify-center text-emerald-600 font-extrabold text-2xl border border-emerald-100 dark:border-emerald-900/50 flex-shrink-0">
        ${t.company.charAt(0).toUpperCase()}
      </div>
      <div class="min-w-0">
        <h2 class="text-xl font-bold text-gray-900 dark:text-white font-headline break-words">${t.title}</h2>
        <p class="text-sm font-bold text-emerald-600 dark:text-emerald-400">${t.company}</p>
        <p class="text-xs text-gray-500">${m} · ${c}</p>
      </div>
    </div>

    <div class="space-y-2 text-xs">
      <h4 class="font-bold text-gray-900 dark:text-white uppercase tracking-wider text-[11px]">Job Description</h4>
      <p class="text-gray-600 dark:text-gray-300 leading-relaxed">${t.description}</p>
    </div>

    ${i.length?`
      <div class="space-y-2 text-xs">
        <h4 class="font-bold text-gray-900 dark:text-white uppercase tracking-wider text-[11px]">Requirements</h4>
        <ul class="space-y-1 text-gray-600 dark:text-gray-300">
          ${i.map(e=>`<li class="flex items-start gap-2"><span class="text-emerald-500 flex-shrink-0">•</span>${e}</li>`).join("")}
        </ul>
      </div>
    `:""}

    <div class="pt-4 border-t border-gray-100 dark:border-gray-800 flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3">
      <div class="text-xs text-gray-400">
        Posted: ${new Date(t.created_at).toLocaleDateString("en-GB",{day:"2-digit",month:"short",year:"numeric"})}
      </div>
      <a href="${t.apply_link}" target="_blank" rel="noopener noreferrer"
        class="px-6 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-xl text-xs shadow-md transition-all flex items-center gap-2">
        Apply Now
        <span class="material-symbols-outlined text-sm">open_in_new</span>
      </a>
    </div>
  `,r.classList.remove("hidden"),(d=document.getElementById("close-job-modal-btn"))==null||d.addEventListener("click",()=>{r.classList.add("hidden")})}function g(t,r){t.textContent=r,t.classList.remove("hidden")}function T(){var r,o;(r=document.getElementById("post-job-form"))==null||r.reset(),(o=document.getElementById("job-form-error"))==null||o.classList.add("hidden");const t=document.getElementById("job-submit-btn");t&&(t.disabled=!1,t.textContent="Submit for Admin Approval")}
